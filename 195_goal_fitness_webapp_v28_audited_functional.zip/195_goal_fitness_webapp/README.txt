195 Goal Fitness v28 Audited Functional Build

Open index.html locally for testing or host this folder as a static web app.

Core features:
- First-time profile setup
- Today dashboard
- Guided workout coach
- Exercise-by-exercise tracking
- Set completion tracking
- Rest timers
- Adaptive voice coach
- Pain/safety tracker
- Supplement coach
- Food/protein logging
- Weight/progress tracking
- Activity/recovery tracking
- Scale/body composition entries
- Backup/export/import
- Privacy/PIN lock
- Offline/PWA support

Read AUDIT_REPORT.md for what changed from the previous package.
